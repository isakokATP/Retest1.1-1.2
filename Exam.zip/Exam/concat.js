function concatArray(array1, array2) {
    if(array1,array2 === null || array1,array2 === undefined) {
        return undefined;
    }
    if(array1.length === 0 || array2.length === 0) {
        return [];
    }
    if(array1.length === 0 || array2.length === 0) {

    }
}

console.log(concatArray());